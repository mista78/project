<?php 

function conditions($req) {

	return $req;
}