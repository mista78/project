<!DOCTYPE html>
<html>
	<head>
		<title>
			Project
		</title>
		<link rel="stylesheet" href="/<?= CompileCss("assets/sass/") ?>">
	</head>
	<body>
		
		<?=  getWidjet("blockcontainer",$view); ?>
		<script src="/<?= CompileJs() ?>"></script>
	</body>
</html>