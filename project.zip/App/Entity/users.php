<?php  

	/**
	 * int
	 */
	$id;


	/**
	 * int
	 */
	$rank;

	/**
	 * varchar(50)
	 */
	$name;

	/**
	 * varchar(255)
	 */
	$email;

	/**
	 * varchar(255)
	 */
	$password;

	/**
	 * varchar(255)
	 */
	$created;

	/**
	 * varchar(255)
	 */
	$updated;