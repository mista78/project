<?php 

return array(

	'host' => 'localhost',
	'base' => 'test',
	'user' => 'root',
	'pass' => '',

);