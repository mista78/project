<?php  
	
	$layouts["content"] = [
		[
			"container" => true,
			"item" => [
				[
					"type" => "text",
					"title" => "Project blog"
				]
			]
		],
	];
	return $layouts;