<?php
	
	/**
	 * @Route('', home/index)
	 */
	function index() {
		
	}

	/**
	 * @Prefix(editor,ajax)
	 * @Route(blog, home/blog)
	 */
	function blog() {
		
	}