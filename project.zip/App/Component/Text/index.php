<div class="Text">
	<?= isset($title) ? tag($title, "h1") : null ?>
	<?= isset($text) ? tag($text, "p") : null ?>
</div>